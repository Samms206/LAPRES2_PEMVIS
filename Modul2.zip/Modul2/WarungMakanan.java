/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

import java.awt.HeadlessException;
import javax.swing.JOptionPane;

/**
 *
 * @author macbookpro
 */
public class WarungMakanan extends javax.swing.JFrame {

    private String makanan, qty;
    private int harga, jumlah, total;
    
    public WarungMakanan() {
        initComponents();
        bMinus.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Lmakanan = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        LjumlahPesan = new javax.swing.JLabel();
        Lharga = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        Ltotal = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        eSotoAyam = new javax.swing.JRadioButton();
        eNasiRames = new javax.swing.JRadioButton();
        eNasiPecel = new javax.swing.JRadioButton();
        eNasiRawon = new javax.swing.JRadioButton();
        eLalapanLele = new javax.swing.JRadioButton();
        eLalapanAyam = new javax.swing.JRadioButton();
        eLalapanTelur = new javax.swing.JRadioButton();
        eMieAyam = new javax.swing.JRadioButton();
        eAyamGeprek = new javax.swing.JRadioButton();
        Lqty = new javax.swing.JLabel();
        bPlus = new javax.swing.JButton();
        bHapus = new javax.swing.JButton();
        bMinus = new javax.swing.JButton();
        bBeli = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Warung Madura");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Helvetica", 1, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("PESANAN");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 20, 220, -1));

        jLabel4.setText("Makanan :");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel7.setText("Jumlah    :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        Lmakanan.setText("-");
        jPanel2.add(Lmakanan, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 120, -1));

        jLabel10.setText("Jumlah    :");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        LjumlahPesan.setText("-");
        jPanel2.add(LjumlahPesan, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 120, -1));

        Lharga.setText("-");
        jPanel2.add(Lharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 120, -1));

        jLabel13.setText("Harga      :");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel14.setText("Total       :");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        Ltotal.setText("-");
        jPanel2.add(Ltotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 120, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 230, 370));

        jLabel1.setFont(new java.awt.Font("Helvetica", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("==============================================");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 380, -1));

        buttonGroup1.add(eSotoAyam);
        eSotoAyam.setText("Soto Ayam");
        jPanel1.add(eSotoAyam, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, -1, -1));

        buttonGroup1.add(eNasiRames);
        eNasiRames.setText("Nasi Rames");
        jPanel1.add(eNasiRames, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        buttonGroup1.add(eNasiPecel);
        eNasiPecel.setText("Nasi Pecel");
        jPanel1.add(eNasiPecel, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, -1, -1));

        buttonGroup1.add(eNasiRawon);
        eNasiRawon.setText("Nasi Rawon");
        jPanel1.add(eNasiRawon, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        buttonGroup1.add(eLalapanLele);
        eLalapanLele.setText("Lalapan Lele");
        jPanel1.add(eLalapanLele, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, -1, -1));

        buttonGroup1.add(eLalapanAyam);
        eLalapanAyam.setText("Lalapan Ayam");
        jPanel1.add(eLalapanAyam, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, -1, -1));

        buttonGroup1.add(eLalapanTelur);
        eLalapanTelur.setText("Lalapan Telur");
        jPanel1.add(eLalapanTelur, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, -1, -1));

        buttonGroup1.add(eMieAyam);
        eMieAyam.setText("Mie Ayam");
        jPanel1.add(eMieAyam, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, -1, -1));

        buttonGroup1.add(eAyamGeprek);
        eAyamGeprek.setText("Ayam Geprek");
        jPanel1.add(eAyamGeprek, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        Lqty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Lqty.setText("0");
        jPanel1.add(Lqty, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, 30, -1));

        bPlus.setBackground(new java.awt.Color(255, 255, 255));
        bPlus.setText("+");
        bPlus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPlusActionPerformed(evt);
            }
        });
        jPanel1.add(bPlus, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 40, 40));

        bHapus.setBackground(new java.awt.Color(255, 255, 255));
        bHapus.setText("Hapus");
        bHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bHapusActionPerformed(evt);
            }
        });
        jPanel1.add(bHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 110, 40));

        bMinus.setBackground(new java.awt.Color(255, 255, 255));
        bMinus.setText("-");
        bMinus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMinusActionPerformed(evt);
            }
        });
        jPanel1.add(bMinus, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 40, 40));

        bBeli.setBackground(new java.awt.Color(255, 255, 255));
        bBeli.setText("Beli");
        bBeli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBeliActionPerformed(evt);
            }
        });
        jPanel1.add(bBeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, 110, 40));

        jLabel5.setFont(new java.awt.Font("Helvetica", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("===== WARUNG MADURA 24 JAM =====");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 20, 370, -1));

        jLabel6.setText("Jumlah");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 370));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bMinusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMinusActionPerformed
        // TODO add your handling code here:
        qty = Lqty.getText();
        if ("1".equals(qty)) {
            bMinus.setEnabled(false);
        }
        jumlah = Integer.parseInt(qty);
        jumlah = jumlah - 1;
        Lqty.setText(String.valueOf(jumlah));
    }//GEN-LAST:event_bMinusActionPerformed

    private void bPlusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPlusActionPerformed
        // TODO add your handling code here:
        qty = Lqty.getText();
        if ("0".equals(qty)) {
            bMinus.setEnabled(true);
        }
        jumlah = Integer.parseInt(qty);
        jumlah = jumlah + 1;
        Lqty.setText(String.valueOf(jumlah));
    }//GEN-LAST:event_bPlusActionPerformed

    private void bBeliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBeliActionPerformed
        // TODO add your handling code here:
        try {
            qty = Lqty.getText();
            if (eNasiRames.isSelected()) {
                    makanan = "Nasi Rames";
                    harga = 6000;
                }else if (eNasiPecel.isSelected()) {
                    makanan = "Nasi Pecel";
                    harga = 7000;
                }else if (eSotoAyam.isSelected()) {
                    makanan = "Soto Ayam";
                    harga = 8000;
                }else if (eNasiRawon.isSelected()) {
                    makanan = "Nasi Rawon";
                    harga = 7000;
                }else if (eLalapanLele.isSelected()) {
                    makanan = "Lalapan Lele";
                    harga = 9000;
                }else if (eLalapanAyam.isSelected()) {
                    makanan = "Lalapan Ayam";
                    harga = 8000;
                }else if (eAyamGeprek.isSelected()) {
                    makanan = "Ayam Geprek";
                    harga = 10000;
                }else if (eMieAyam.isSelected()) {
                    makanan = "Mie Ayam";
                    harga = 8000;
                }else if (eLalapanTelur.isSelected()) {
                    makanan = "Lalapan Telur";
                    harga = 6000;
                }
            if (!makanan.isEmpty()) {
                Lmakanan.setText(makanan);
                Lharga.setText(String.valueOf(harga));
                LjumlahPesan.setText(Lqty.getText());
                jumlah = Integer.parseInt(Lqty.getText());
                total = harga * jumlah;
                Ltotal.setText(String.valueOf(total));
            }else{
                JOptionPane.showMessageDialog(this, "Anda belum memilih makanan!");
            }
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "anda belum memilih makanan");
        }

    }//GEN-LAST:event_bBeliActionPerformed

    private void bHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bHapusActionPerformed
        // TODO add your handling code here:
        buttonGroup1.clearSelection();
        Lqty.setText("0");
        Lmakanan.setText("-");
        Lharga.setText("-");
        LjumlahPesan.setText("-");
        Ltotal.setText("-");
        bMinus.setEnabled(false);
        makanan = null;
        harga= 0;
        jumlah = 0;
        total = 0;

    }//GEN-LAST:event_bHapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WarungMakanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WarungMakanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WarungMakanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WarungMakanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WarungMakanan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lharga;
    private javax.swing.JLabel LjumlahPesan;
    private javax.swing.JLabel Lmakanan;
    private javax.swing.JLabel Lqty;
    private javax.swing.JLabel Ltotal;
    private javax.swing.JButton bBeli;
    private javax.swing.JButton bHapus;
    private javax.swing.JButton bMinus;
    private javax.swing.JButton bPlus;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton eAyamGeprek;
    private javax.swing.JRadioButton eLalapanAyam;
    private javax.swing.JRadioButton eLalapanLele;
    private javax.swing.JRadioButton eLalapanTelur;
    private javax.swing.JRadioButton eMieAyam;
    private javax.swing.JRadioButton eNasiPecel;
    private javax.swing.JRadioButton eNasiRames;
    private javax.swing.JRadioButton eNasiRawon;
    private javax.swing.JRadioButton eSotoAyam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
